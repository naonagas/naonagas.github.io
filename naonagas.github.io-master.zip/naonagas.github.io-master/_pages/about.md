---
permalink: /
title: "Naoya Nagasaka"
author_profile: true
redirect_from: 
  - /about/
  - /about.html
---

Welcome to my website! I am a Ph.D. student in Economics at Indiana University. I am interested in Macroeconomics and Econometrics, with a particular focus on methodological and empirical investigation of nonlinearity and cross-sectional heterogeneity in macroeconomy.
