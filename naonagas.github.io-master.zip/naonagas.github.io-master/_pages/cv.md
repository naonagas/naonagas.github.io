---
layout: archive
title: "CV"
permalink: /cv/
author_profile: true
redirect_from:
  - /resume
---

You can download my CV from [here](https://naonagas.github.io/files/cv_naoyanagasaka.pdf).
